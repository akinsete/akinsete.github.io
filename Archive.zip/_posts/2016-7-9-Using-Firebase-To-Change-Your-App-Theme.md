---
layout: post
title: This is a completely different game!
---

Next you can update your site name, avatar and other options.